from flask import jsonify
from database import MariaDB
from utils import Validators, mask_card_number


class CardService:

    def add_card(self, user_id, data):
        db = MariaDB()
        try:
            card_number_raw = data.get("card_number", "")
            card_holder = (data.get("card_holder") or "").strip()
            expiry_date = (data.get("expiry_date") or "").strip()

            error, cleaned_number = Validators.validate_card_number(card_number_raw)
            if error:
                return jsonify({"status": "error", "message": error}), 400

            error = Validators.validate_card_holder(card_holder)
            if error:
                return jsonify({"status": "error", "message": error}), 400

            error = Validators.validate_expiry(expiry_date)
            if error:
                return jsonify({"status": "error", "message": error}), 400

            # Prevent the exact same card being added twice for this user
            db.execute("SELECT id FROM user_cards WHERE user_id = ? AND card_number = ?", (user_id, cleaned_number))
            if db.fetchone():
                return jsonify({"status": "error", "message": "This card is already linked to your account."}), 400

            card_type = Validators.detect_card_type(cleaned_number)

            db.execute(
                "INSERT INTO user_cards (user_id, card_number, card_holder, expiry_date, card_type) VALUES (?, ?, ?, ?, ?)",
                (user_id, cleaned_number, card_holder, expiry_date, card_type)
            )
            db.commit()
            return jsonify({"status": "success", "message": "Card added successfully."}), 201

        except Exception as e:
            db.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            db.close()

    def get_cards(self, user_id):
        db = MariaDB()
        try:
            db.execute(
                "SELECT id, card_number, card_holder, expiry_date, card_type FROM user_cards WHERE user_id = ? ORDER BY id DESC",
                (user_id,)
            )
            rows = db.fetchall()
            cards = [{
                "id": r[0],
                "card_number": mask_card_number(r[1]),
                "card_holder": r[2],
                "expiry_date": r[3],
                "card_type": r[4]
            } for r in rows]
            return jsonify({"status": "success", "count": len(cards), "data": cards}), 200
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            db.close()

    def delete_card(self, user_id, card_id):
        db = MariaDB()
        try:
            db.execute("SELECT id FROM user_cards WHERE id = ? AND user_id = ?", (card_id, user_id))
            if not db.fetchone():
                return jsonify({"status": "error", "message": "Card not found."}), 404

            db.execute("DELETE FROM user_cards WHERE id = ? AND user_id = ?", (card_id, user_id))
            db.commit()
            return jsonify({"status": "success", "message": "Card removed successfully."}), 200
        except Exception as e:
            db.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            db.close()