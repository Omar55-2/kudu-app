import re
from datetime import datetime

class Validators:
    # Auth / profile fields
    @staticmethod
    def validate_username(username):
        if not username or not (3 <= len(username) <= 50):
            return "Username must be between 3 and 50 characters."
        if not re.match(r"^[A-Za-z0-9_]+$", username): #alphanumeric & underscore
            return "Username can only contain letters, numbers, and underscores."
        return None

    @staticmethod
    def validate_email(email):
        if not email or not re.match(r"^[^\s@]+@[^\s@]+\.[^\s@]+$", email):
            return "Enter a valid email address."
        return None

    @staticmethod
    def validate_phone(phone):
        if not phone or not re.match(r"^\+?\d{10}$", phone):
            return "Enter a valid phone number (10 digits)."
        return None

    @staticmethod
    def validate_password(password):
        if not password or len(password) < 8:
            return "Password must be at least 8 characters long."
        if not re.search(r"[A-Z]", password):
            return "Password must contain at least one uppercase letter."
        if not re.search(r"[a-z]", password):
            return "Password must contain at least one lowercase letter."
        if not re.search(r"\d", password):
            return "Password must contain at least one number."
        return None

    # Card fields 
    @staticmethod
    def validate_card_number(card_number):
        #remove spaces or dashes inside the number
        #1234 1234 1234 1234  =  1234123412341234
        #1234-1234-1234-1234  =  1234123412341234
        cleaned = (card_number or "").replace(" ", "").replace("-", "")
        if not cleaned.isdigit() or not (16 <= len(cleaned) <= 19):
            return "Card number must be 16-19 digits.", None
        if not Validators.card_check(cleaned):
            return "Card number failed validation (not a real card number).", None
        return None, cleaned

#Luhn Algorithm ("Mod 10" algorithm)
    @staticmethod
    def card_check(number):
        digits = [int(d) for d in number] #number to list
        digits.reverse() #revers the list
        total = 0

        # Double every second index
        # 2154 86547 1425 4524
        for i, d in enumerate(digits):
            if i % 2 == 1:
                d *= 2
                if d > 9:
                    d -= 9
            total += d
        return total % 10 == 0

    @staticmethod
    def validate_card_holder(name):
        if not name or not re.match(r"^[A-Za-z\s.'-]{2,100}$", name):
            return "Card holder name must contain letters only."
        return None

    @staticmethod
    def validate_expiry(expiry_date):
    #months 01 through 12, followed by /, followed by 2-digit year
        if not expiry_date or not re.match(r"^(0[1-9]|1[0-2])\/\d{2}$", expiry_date):
            return "Expiry date must be in MM/YY format."
        month, year = expiry_date.split("/")
        exp_year = 2000 + int(year)
        now = datetime.now()
        if exp_year < now.year or (exp_year == now.year and int(month) < now.month):
            return "This card has already expired."
        return None

    @staticmethod
    def detect_card_type(cleaned_number):
        if cleaned_number.startswith("4"):
            return "Visa"
        if cleaned_number[:2] in ("51", "52", "53", "54", "55"):
            return "Mastercard"
        return "Visa"
    

    #Transaction fields
    @staticmethod
    def validate_amount(amount):
        try:
            amount = float(amount) #is it a number?
        except (TypeError, ValueError):
            return "Amount must be a valid number.", None
        if amount <= 0:
            return "Transfer amount must be greater than zero.", None
        if amount > 100000:
            return "Transfer amount exceeds the allowed limit.", None
        return None, round(amount, 2)


def mask_card_number(card_number):
    cleaned = (card_number or "").replace(" ", "")
    if len(cleaned) < 4:
        return cleaned
    return f"**** **** **** {cleaned[-4:]}"










# @staticmethod, which means:

# They do not require an instance of the class
# They do not use self
# You can call them like this:
