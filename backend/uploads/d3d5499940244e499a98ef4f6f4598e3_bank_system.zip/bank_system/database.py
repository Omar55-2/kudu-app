import mariadb

class MariaDB:
    def __init__(self):
        self.connection = mariadb.connect(
            host="127.0.0.1",
            port=3306,
            user="root",
            password="Ss79317931",
            database="online_banking"
        )
        self.cursor = self.connection.cursor()

    def execute(self, sql, values=None):
        if self.cursor:
            self.cursor.close()
        self.cursor = self.connection.cursor()
        if values:
            self.cursor.execute(sql, values)
        else:
            self.cursor.execute(sql)

    def fetchone(self):
        return self.cursor.fetchone()

    def fetchall(self):
        return self.cursor.fetchall()

    def commit(self):
        self.connection.commit()

    def rollback(self):
        self.connection.rollback()

    def close(self):
        self.cursor.close()
        self.connection.close()


db = MariaDB()

db.execute("""CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    balance DOUBLE DEFAULT 10000.00,
    is_active TINYINT DEFAULT 1,
    is_suspended TINYINT DEFAULT 0,
    failed_attempts INT DEFAULT 0
);""")

db.execute("""CREATE TABLE IF NOT EXISTS user_otps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(120) NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    purpose VARCHAR(20) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    is_verified TINYINT DEFAULT 0
);""")

db.execute("""CREATE TABLE IF NOT EXISTS user_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    card_number VARCHAR(19) NOT NULL,
    card_holder VARCHAR(100) NOT NULL,
    expiry_date VARCHAR(5) NOT NULL,
    card_type VARCHAR(20) DEFAULT 'Visa',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);""")

db.execute("""CREATE TABLE IF NOT EXISTS user_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DOUBLE NOT NULL,
    timestamp TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);""")

db.commit()
print("Online banking schema verified/ready.")
db.close()
