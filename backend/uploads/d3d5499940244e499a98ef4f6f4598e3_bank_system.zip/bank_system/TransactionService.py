from flask import jsonify
from database import MariaDB
from utils import Validators


class TransactionService:

    def get_transactions(self, user_id, search=None):
        db = MariaDB()
        try:
            query = "SELECT id, description, amount, timestamp FROM user_transactions WHERE user_id = ?"
            values = [user_id]

            if search:
                query += " AND description LIKE ?"
                values.append(f"%{search}%")

            query += " ORDER BY timestamp DESC, id DESC"

            db.execute(query, tuple(values))
            rows = db.fetchall()
            transactions = [{
                "id": r[0],
                "description": r[1],
                "amount": float(r[2]),
                "timestamp": r[3].strftime("%Y-%m-%d %H:%M:%S") if r[3] else None
            } for r in rows]
            return jsonify({"status": "success", "count": len(transactions), "data": transactions}), 200
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            db.close()

    def transfer_money(self, sender_id, data):
        db = MariaDB()
        try:
            recipient_input = (data.get("recipient") or "").strip().lower()
            description = (data.get("description") or "").strip() or "Funds transfer"

            if not recipient_input:
                return jsonify({"status": "error", "message": "Recipient username or email is required."}), 400

            error, amount = Validators.validate_amount(data.get("amount"))
            if error:
                return jsonify({"status": "error", "message": error}), 400

            # Sender info
            db.execute("SELECT id, username, balance, is_active, is_suspended FROM users WHERE id = ?", (sender_id,))
            sender = db.fetchone()
            if not sender:
                return jsonify({"status": "error", "message": "Sender account not found."}), 404

            _, sender_username, sender_balance, sender_active, sender_suspended = sender

            if not sender_active:
                return jsonify({"status": "error", "message": "Your account is closed. Contact support."}), 403
            if sender_suspended:
                return jsonify({"status": "error", "message": "Your account is suspended. Please visit the bank."}), 403

            # Recipient lookup by username OR email
            db.execute(
                "SELECT id, username, is_active FROM users WHERE LOWER(username) = ? OR LOWER(email) = ?",
                (recipient_input, recipient_input)
            )
            recipient = db.fetchone()
            if not recipient:
                return jsonify({"status": "error", "message": "Recipient not found in the system."}), 404

            recipient_id, recipient_username, recipient_active = recipient

            if recipient_id == sender_id:
                return jsonify({"status": "error", "message": "You cannot transfer money to yourself."}), 400
            if not recipient_active:
                return jsonify({"status": "error", "message": "Recipient account is closed."}), 400

            if amount > float(sender_balance):
                return jsonify({"status": "error", "message": "Insufficient balance for this transfer."}), 400

            # Perform the transfer as a single atomic unit
            new_sender_balance = round(float(sender_balance) - amount, 2)
            db.execute("UPDATE users SET balance = ? WHERE id = ?", (new_sender_balance, sender_id))

            db.execute("UPDATE users SET balance = balance + ? WHERE id = ?", (amount, recipient_id))

            db.execute(
                "INSERT INTO user_transactions (user_id, description, amount) VALUES (?, ?, ?)",
                (sender_id, f"Transfer to {recipient_username}: {description}", -amount)
            )
            db.execute(
                "INSERT INTO user_transactions (user_id, description, amount) VALUES (?, ?, ?)",
                (recipient_id, f"Transfer from {sender_username}: {description}", amount)
            )

            db.commit()
            return jsonify({
                "status": "success",
                "message": f"Successfully transferred {amount} to {recipient_username}.",
                "new_balance": new_sender_balance
            }), 201

        except Exception as e:
            db.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            db.close()
