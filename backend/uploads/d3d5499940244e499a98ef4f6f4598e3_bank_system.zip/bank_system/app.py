from flask import Flask, request, render_template, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash #hashing helper
from database import MariaDB
from CardService import CardService
from TransactionService import TransactionService
from utils import Validators
from functools import wraps
import random
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "secure_online_banking_directory_key_secret_string"

card_service = CardService()
transaction_service = TransactionService()

MAX_FAILED_ATTEMPTS = 3

# Mailtrap Configuration
MAILTRAP_HOST = "sandbox.smtp.mailtrap.io"
MAILTRAP_PORT = 2525
MAILTRAP_USER = "640a149cd83f12"
MAILTRAP_PASS = "95e73f0fdc3255"
SENDER_EMAIL = "security@onlinebanking.local"

def send_otp_email(target_email, otp, purpose_text):
    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = target_email
    msg['Subject'] = f"Confirm your Identity - {purpose_text.upper()}"

    body = f"""
    <div style="font-family: sans-serif; padding: 20px; border: 1px solid #e5e7eb; border-radius: 12px; max-width: 500px;">
        <h2 style="color: #1e3a8a; margin-bottom: 4px;">Online Banking Security Gate</h2>
        <p style="color: #4b5563; font-size: 14px;">Your 6-digit one-time authorization code for <strong>{purpose_text}</strong> is:</p>
        <div style="background-color: #f3f4f6; padding: 16px; border-radius: 8px; text-align: center; margin: 20px 0;">
            <span style="font-family: monospace; font-size: 32px; font-weight: bold; letter-spacing: 4px; color: #1d4ed8;">{otp}</span>
        </div>
        <p style="color: #9ca3af; font-size: 12px;">This code will expire in 5 minutes. Never share it with anyone.</p>
    </div>
    """
    msg.attach(MIMEText(body, 'html'))

    try:
        with smtplib.SMTP(MAILTRAP_HOST, MAILTRAP_PORT) as server:
            server.starttls()
            server.login(MAILTRAP_USER, MAILTRAP_PASS)
            server.sendmail(SENDER_EMAIL, target_email, msg.as_string())
        return True
    except Exception as e:
        print("SMTP Transmission Failure:", e)
        return False

# Route Security Gate
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login_view"))
        return f(*args, **kwargs)
    return decorated_function

# SIGN UP ROUTE
@app.route("/signup", methods=["GET", "POST"])
def signup_view():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone_number", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        #Fvalidation (valid ID/Email/Pass&Confirm/Phone)
        error = Validators.validate_username(username)
        if error:
            flash(error, "danger")
            return render_template("signup.html")

        error = Validators.validate_email(email)
        if error:
            flash(error, "danger")
            return render_template("signup.html")

        error = Validators.validate_phone(phone)
        if error:
            flash(error, "danger")
            return render_template("signup.html")

        error = Validators.validate_password(password)
        if error:
            flash(error, "danger")
            return render_template("signup.html")

        #Passwords must match
        if password != confirm_password:
            flash("Password and confirmation password do not match.", "danger")
            return render_template("signup.html")

        db = MariaDB()

        #Uniqueness checks
        db.execute("SELECT id FROM users WHERE username = ? OR email = ?", (username, email))
        existing_user = db.fetchone()

        if existing_user:
            db.close()
            flash("An account with this username or email already exists.", "danger")
            return render_template("signup.html")

        password_hash = generate_password_hash(password)

        db.execute(
            "INSERT INTO users (username, email, phone_number, password_hash) VALUES (?, ?, ?, ?)",
            (username, email, phone, password_hash)
        )

        otp_code = str(random.randint(100000, 999999))
        expiry_time = datetime.now() + timedelta(minutes=5)

        db.execute(
            "INSERT INTO user_otps (email, otp_code, purpose, expires_at) VALUES (?, ?, 'signup', ?)",
            (email, otp_code, expiry_time)
        )
        db.commit()
        db.close()

        if send_otp_email(email, otp_code, "Account Registration"):
            return redirect(url_for("verify_view", email=email, purpose="signup"))
        else:
            flash("Account registered, but Mailtrap failed to send the OTP code.", "danger")
            return render_template("signup.html")

    return render_template("signup.html")

# LOGIN ROUTE (Username + Password)
@app.route("/login", methods=["GET", "POST"])
def login_view():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        db = MariaDB()
        db.execute(
            "SELECT id, password_hash, is_active, is_suspended, failed_attempts, email FROM users WHERE username = ?",
            (username,)
        )
        user_record = db.fetchone()

        if not user_record:
            db.close()
            flash("Invalid username or password.", "danger")
            return render_template("login.html")

        user_id, password_hash, is_active, is_suspended, failed_attempts, email = user_record

        #Close the account after 3 wrong tries
        if not is_active:
            db.close()
            flash("This account has been closed. Contact support.", "danger")
            return render_template("login.html")

        if not check_password_hash(password_hash, password):
            failed_attempts += 1
            if failed_attempts >= MAX_FAILED_ATTEMPTS:
                db.execute("UPDATE users SET failed_attempts = ?, is_active = 0 WHERE id = ?", (failed_attempts, user_id))
                db.commit()
                db.close()
                flash("Account closed after 3 incorrect attempts. Contact support to reactivate.", "danger")
                return render_template("login.html")

            db.execute("UPDATE users SET failed_attempts = ? WHERE id = ?", (failed_attempts, user_id))
            db.commit()
            db.close()
            remaining = MAX_FAILED_ATTEMPTS - failed_attempts
            flash(f"Invalid username or password. {remaining} attempt(s) remaining before account closure.", "danger")
            return render_template("login.html")

        # Correct password: reset failed attempt counter
        db.execute("UPDATE users SET failed_attempts = 0 WHERE id = ?", (user_id,))

        # Business Rule: OTP verification after valid login
        otp_code = str(random.randint(100000, 999999))
        expiry_time = datetime.now() + timedelta(minutes=5)

        db.execute(
            "INSERT INTO user_otps (email, otp_code, purpose, expires_at) VALUES (?, ?, 'login', ?)",
            (email, otp_code, expiry_time)
        )
        db.commit()
        db.close()

        if send_otp_email(email, otp_code, "Login Authorization"):
            return redirect(url_for("verify_view", email=email, purpose="login"))
        else:
            flash("Login validated, but Mailtrap failed to deliver the OTP.", "danger")
            return render_template("login.html")

    return render_template("login.html")

# OTP CODE VERIFICATION GATEWAY
@app.route("/verify", methods=["GET", "POST"])
def verify_view():
    email = request.args.get("email") or request.form.get("email")
    purpose = request.args.get("purpose") or request.form.get("purpose")

    if not email or not purpose:
        return redirect(url_for("login_view"))

    if request.method == "POST":
        otp_entered = request.form.get("otp", "").strip()

        db = MariaDB()
        db.execute(
            """SELECT id, otp_code FROM user_otps
               WHERE email = ? AND purpose = ? AND is_verified = 0 AND expires_at > NOW()
               ORDER BY id DESC LIMIT 1""",
            (email, purpose)
        )
        otp_record = db.fetchone()

        if otp_record and otp_record[1] == otp_entered:
            db.execute("UPDATE user_otps SET is_verified = 1 WHERE id = ?", (otp_record[0],))

            db.execute("SELECT id FROM users WHERE email = ?", (email,))
            user_row = db.fetchone()
            db.commit()
            db.close()

            session["user_id"] = user_row[0]
            session["user_email"] = email
            session.permanent = True
            return redirect(url_for("index"))
        else:
            db.close()
            flash("Invalid or expired code. Please try again.", "danger")
            return render_template("verify.html", email=email, purpose=purpose)

    return render_template("verify.html", email=email, purpose=purpose)


@app.route("/logout")
def logout():
    user_email = session.get("user_email")
    if user_email:
        db = MariaDB()
        db.execute("DELETE FROM user_otps WHERE email = ?", (user_email,))
        db.commit()
        db.close()

    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login_view"))


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password_view():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()

        error = Validators.validate_email(email)
        if error:
            flash(error, "danger")
            return render_template("forgot_password.html")

        db = MariaDB()
        db.execute("SELECT id FROM users WHERE email = ?", (email,))
        user_record = db.fetchone()

        if not user_record:
            db.close()
            # Security practice: don't reveal if the account exists or not
            flash("If this account exists, a recovery code has been sent.", "success")
            return render_template("forgot_password.html")

        otp_code = str(random.randint(100000, 999999))
        expiry_time = datetime.now() + timedelta(minutes=5)

        db.execute(
            "INSERT INTO user_otps (email, otp_code, purpose, expires_at) VALUES (?, ?, 'reset', ?)",
            (email, otp_code, expiry_time)
        )
        db.commit()
        db.close()

        send_otp_email(email, otp_code, "Password Recovery")
        return render_template("reset_password.html", email=email)

    return render_template("forgot_password.html")


@app.route("/reset-password", methods=["POST"])
def reset_password_action():
    email = request.form.get("email", "").strip().lower()
    otp_provided = request.form.get("otp", "").strip()
    new_password = request.form.get("password", "")
    confirm_password = request.form.get("confirm_password", "")

    error = Validators.validate_password(new_password)
    if error:
        flash(error, "danger")
        return render_template("reset_password.html", email=email)

    if new_password != confirm_password:
        flash("Password and confirmation password do not match.", "danger")
        return render_template("reset_password.html", email=email)

    db = MariaDB()
    db.execute(
        "SELECT id FROM user_otps WHERE email = ? AND otp_code = ? AND purpose = 'reset' AND expires_at > NOW()",
        (email, otp_provided)
    )
    otp_record = db.fetchone()

    if not otp_record:
        db.close()
        flash("Invalid or expired recovery code.", "danger")
        return render_template("reset_password.html", email=email)

    db.execute("DELETE FROM user_otps WHERE email = ? AND purpose = 'reset'", (email,))
    db.execute(
        "UPDATE users SET password_hash = ?, is_active = 1, failed_attempts = 0 WHERE email = ?",
        (generate_password_hash(new_password), email)
    )
    db.commit()
    db.close()

    flash("Password updated successfully. Please log in with your new credentials.", "success")
    return redirect(url_for("login_view"))


# Web Frontends
@app.route("/")
@login_required
def index():
    return render_template("index_1.html", username=session.get("user_email"))


@app.route("/api/profile", methods=["GET"])
@login_required
def get_profile():
    db = MariaDB()
    try:
        db.execute(
            "SELECT username, email, balance, is_suspended FROM users WHERE id = ?",
            (session["user_id"],)
        )
        row = db.fetchone()
        if not row:
            return jsonify({"status": "error", "message": "Profile not found."}), 404

        return jsonify({
            "status": "success",
            "data": {
                "username": row[0],
                "email": row[1],
                "balance": float(row[2]),
                "is_suspended": bool(row[3])
            }
        }), 200
    finally:
        db.close()


# Card APIs
@app.route("/api/cards", methods=["GET"])
@login_required
def get_cards():
    return card_service.get_cards(session["user_id"])


@app.route("/api/cards", methods=["POST"])
@login_required
def add_card():
    return card_service.add_card(session["user_id"], request.get_json(force=True))


@app.route("/api/cards/<int:card_id>", methods=["DELETE"])
@login_required
def delete_card(card_id):
    return card_service.delete_card(session["user_id"], card_id)


# Transaction APIs
@app.route("/api/transactions", methods=["GET"])
@login_required
def get_transactions():
    search = request.args.get("search")
    return transaction_service.get_transactions(session["user_id"], search)


@app.route("/api/transactions/transfer", methods=["POST"])
@login_required
def transfer_money():
    return transaction_service.transfer_money(session["user_id"], request.get_json(force=True))


if __name__ == "__main__":
    app.run(debug=True, port=502)


#Password Hashing: Passwords are never stored as plaintext
#Attack Protection: Accounts are closed if enter wrong password 3 times 