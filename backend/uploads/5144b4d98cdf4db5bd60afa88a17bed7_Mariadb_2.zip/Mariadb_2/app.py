from flask import Flask, request, render_template, redirect, url_for, session, flash, jsonify
from PersonService import PersonService
from database import MariaDB
from functools import wraps
import random
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "secure_system_directory_key_secret_string"
service = PersonService()

# --- Mailtrap Configuration ---
MAILTRAP_HOST = "sandbox.smtp.mailtrap.io"
MAILTRAP_PORT = 2525
MAILTRAP_USER = "YOUR_MAILTRAP_USERNAME"  # Replace with your Mailtrap SMTP User
MAILTRAP_PASS = "YOUR_MAILTRAP_PASSWORD"  # Replace with your Mailtrap SMTP Password
SENDER_EMAIL = "security@directorycore.local"

def send_otp_email(target_email, otp):
    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = target_email
    msg['Subject'] = "Your Security Verification Passcode"

    body = f"""
    <div style="font-family: sans-serif; padding: 20px; border: 1px solid #e5e7eb; border-radius: 12px; max-width: 500px;">
        <h2 style="color: #1e3a8a; margin-bottom: 4px;">Directory Core Security</h2>
        <p style="color: #4b5563; font-size: 14px;">An authentication entry code was requested for this address.</p>
        <div style="background-color: #f3f4f6; padding: 16px; border-radius: 8px; text-align: center; margin: 20px 0;">
            <span style="font-family: monospace; font-size: 32px; font-weight: bold; letter-spacing: 4px; color: #1d4ed8;">{otp}</span>
        </div>
        <p style="color: #9ca3af; font-size: 12px;">This verification token will expire in 5 minutes.</p>
    </div>
    """
    msg.attach(MIMEText(body, 'html'))

    try:
        with smtplib.SMTP(MAILTRAP_HOST, MAILTRAP_PORT) as server:
            server.starttls()
            server.login(MAILTRAP_USER, MAILTRAP_PASS)
            server.sendmail(SENDER_EMAIL, target_email, msg.as_string())
        return True
    except Exception as e:
        print("SMTP Error caught:", e)
        return False

# --- Route Guard Protection ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_email" not in session:
            return redirect(url_for("login_view"))
        return f(*args, **kwargs)
    return decorated_function

# --- Authentication Views ---
@app.route("/login", methods=["GET", "POST"])
def login_view():
    if request.method == "POST":
        email = request.form.get("email").strip().lower()

        db = MariaDB()
        db.execute("SELECT id FROM users WHERE email = ?", (email,))
        user = db.fetchone()
        
        if not user:
            db.close()
            flash("Access Denied: This email address is not whitelisted.", "danger")
            return render_template("login.html")

        otp_code = str(random.randint(100000, 999999))
        expiry_time = datetime.now() + timedelta(minutes=5)

        db.execute(
            "INSERT INTO user_otps (email, otp_code, expires_at) VALUES (?, ?, ?)",
            (email, otp_code, expiry_time)
        )
        db.commit()
        db.close()

        if send_otp_email(email, otp_code):
            return redirect(url_for("verify_view", email=email))
        else:
            flash("System failed to communicate with Mailtrap server.", "danger")
            return render_template("login.html")

    return render_template("login.html")

@app.route("/verify", methods=["GET", "POST"])
def verify_view():
    email = request.args.get("email") or request.form.get("email")
    if not email:
        return redirect(url_for("login_view"))

    if request.method == "POST":
        otp_entered = request.form.get("otp").strip()

        db = MariaDB()
        db.execute(
            """SELECT id, otp_code FROM user_otps 
               WHERE email = ? AND is_verified = 0 AND expires_at > NOW() 
               ORDER BY id DESC LIMIT 1""", 
            (email,)
        )
        otp_record = db.fetchone()

        if otp_record and otp_record[1] == otp_entered:
            db.execute("UPDATE user_otps SET is_verified = 1 WHERE id = ?", (otp_record[0],))
            db.commit()
            db.close()

            session["user_email"] = email
            session.permanent = True
            return redirect(url_for("index"))
        else:
            db.close()
            flash("Invalid or expired code segment entered.", "danger")
            return render_template("verify.html", email=email)

    return render_template("verify.html", email=email)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login_view"))

# --- Protected Web Frontends ---
@app.route("/")
@login_required
def index():
    return render_template("index.html", username=session.get("user_email"))

@app.route("/add")
@login_required
def add_view():
    return render_template("add_profile.html")

@app.route("/edit")
@login_required
def edit_view():
    return render_template("edit_profile.html")

# --- Protected Data APIs ---
@app.route("/api/people", methods=["POST"])
@login_required
def create():
    return service.create_person(request.get_json(force=True))

@app.route("/api/people", methods=["GET"])
@login_required
def get_all():
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 100000, type=int)
    return service.get_all_people(page, per_page)

@app.route("/api/people/<int:id>", methods=["PUT"])
@login_required
def update(id):
    return service.update_person(id, request.get_json())

@app.route("/api/people/<int:id>", methods=["DELETE"])
@login_required
def delete(id):
    return service.delete_person(id)

if __name__ == "__main__":
    app.run(debug=True)