import mariadb

class MariaDB:
    def __init__(self):
        self.connection = mariadb.connect(
            host="127.0.0.1",
            port=3306,
            user="root",
            password="Ss79317931",
            database="test_db"
        )
        self.cursor = self.connection.cursor()

    def execute(self, sql, values=None):
        if self.cursor:
            self.cursor.close()
            
        self.cursor = self.connection.cursor()

        if values:
            self.cursor.execute(sql, values)
        else:
            self.cursor.execute(sql)
   
    def fetchone(self):
        return self.cursor.fetchone()
        
    def fetchall(self):
        return self.cursor.fetchall()
        
    def commit(self):
        self.connection.commit()
        
    def rollback(self):
        self.connection.rollback()

    def close(self):
        self.cursor.close()
        self.connection.close()